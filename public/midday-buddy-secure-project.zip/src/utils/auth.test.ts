import test from 'node:test';
import assert from 'node:assert/strict';
import { UserProfile, UserRole, UserApprovalStatus } from '../types/index.ts';

// Pure logic helpers for testing
export function validateRegistrationInput(input: {
  name?: string;
  email?: string;
  password?: string;
  confirmPassword?: string;
  employeeId?: string;
}): { valid: boolean; error?: string } {
  if (!input.name || !input.name.trim()) {
    return { valid: false, error: 'Name is required' };
  }
  if (!input.email || !input.email.includes('@')) {
    return { valid: false, error: 'Valid Email ID is required' };
  }
  if (!input.employeeId || !input.employeeId.trim()) {
    return { valid: false, error: 'Employee ID is required' };
  }
  if (!input.password || input.password.length < 6) {
    return { valid: false, error: 'Password must be at least 6 characters' };
  }
  if (input.confirmPassword !== undefined && input.password !== input.confirmPassword) {
    return { valid: false, error: 'Passwords do not match' };
  }
  return { valid: true };
}

export function validateForgotPasswordInput(input: {
  email?: string;
  employeeId?: string;
}): { valid: boolean; error?: string } {
  if (!input.email || !input.email.includes('@')) {
    return { valid: false, error: 'Valid Email ID is required' };
  }
  if (!input.employeeId || !input.employeeId.trim()) {
    return { valid: false, error: 'Employee ID is required' };
  }
  return { valid: true };
}

export function checkUniqueEmployeeId(existingUsers: Array<{ employeeId?: string }>, newEmpId: string): boolean {
  const normalized = (newEmpId || '').trim().toUpperCase();
  if (!normalized) return false;
  return !existingUsers.some((u) => u.employeeId?.trim().toUpperCase() === normalized);
}

export function canBroadcastBreak(user: { status: UserApprovalStatus; role: UserRole }): boolean {
  return user.status === 'approved';
}

export function canAccessAdminPortal(user: { role: UserRole; status: UserApprovalStatus }): boolean {
  return (user.role === 'community_admin' || user.role === 'platform_admin') && user.status === 'approved';
}

import { hashPassword, verifyPassword as verifyPbkdf2Password } from './crypto.ts';


export function canLoginWithoutPassword(user: { passwordResetApproved?: boolean }): boolean {
  return Boolean(user.passwordResetApproved);
}

export function processAdminResetApproval(user: {
  passwordResetRequested?: boolean;
  passwordResetApproved?: boolean;
  mustChangePassword?: boolean;
}) {
  user.passwordResetRequested = false;
  user.passwordResetApproved = true; // Allows one-time passwordless login
  user.mustChangePassword = true;    // Forces immediate password change
  return user;
}

export function processPasswordChange(
  user: {
    password?: string;
    passwordResetApproved?: boolean;
    mustChangePassword?: boolean;
  },
  newPassword: string
): { success: boolean; error?: string } {
  if (!newPassword || newPassword.length < 6) {
    return { success: false, error: 'Password must be at least 6 characters long' };
  }
  user.password = newPassword;
  user.passwordResetApproved = false;
  user.mustChangePassword = false;
  return { success: true };
}

// ==========================================
// TEST SUITE: AUTHENTICATION & ACCESS CONTROL
// ==========================================

test('validateRegistrationInput enforces required fields including Employee ID and password length', () => {
  assert.equal(validateRegistrationInput({}).valid, false);
  assert.equal(validateRegistrationInput({ name: 'Rahul' }).valid, false);
  assert.equal(
    validateRegistrationInput({ name: 'Rahul', email: 'rahul@tcs.com', employeeId: 'EMP-101', password: '123' }).valid,
    false
  );
  assert.equal(
    validateRegistrationInput({ name: 'Rahul', email: 'rahul@tcs.com', password: 'password123', confirmPassword: 'password123' }).valid,
    false // Missing employeeId
  );
  assert.equal(
    validateRegistrationInput({
      name: 'Rahul',
      email: 'rahul@tcs.com',
      employeeId: 'EMP-101',
      password: 'password123',
      confirmPassword: 'different',
    }).valid,
    false
  );
  assert.equal(
    validateRegistrationInput({
      name: 'Rahul',
      email: 'rahul@tcs.com',
      employeeId: 'EMP-101',
      password: 'password123',
      confirmPassword: 'password123',
    }).valid,
    true
  );
});

test('validateForgotPasswordInput enforces Email ID and Employee ID', () => {
  assert.equal(validateForgotPasswordInput({}).valid, false);
  assert.equal(validateForgotPasswordInput({ email: 'user@example.com' }).valid, false);
  assert.equal(validateForgotPasswordInput({ employeeId: 'EMP-999' }).valid, false);
  assert.equal(validateForgotPasswordInput({ email: 'user@example.com', employeeId: 'EMP-999' }).valid, true);
});

test('checkUniqueEmployeeId blocks duplicate employee IDs across cases and spaces', () => {
  const existingUsers = [
    { employeeId: 'EMP-1001' },
    { employeeId: 'ADM-001' },
    { employeeId: 'DEV-404' },
  ];
  assert.equal(checkUniqueEmployeeId(existingUsers, 'EMP-1002'), true);
  assert.equal(checkUniqueEmployeeId(existingUsers, 'emp-1001'), false);
  assert.equal(checkUniqueEmployeeId(existingUsers, ' ADM-001 '), false);
  assert.equal(checkUniqueEmployeeId(existingUsers, ''), false);
});

test('checkUniqueEmployeeId ignores rejected users allowing re-registration', () => {
  const usersWithRejected = [
    { employeeId: 'EMP-1001', status: 'approved' as UserApprovalStatus },
    { employeeId: 'REJECT-999', status: 'rejected' as UserApprovalStatus },
  ];
  // Filter active users: rejected records release the employee ID
  const activeOnly = usersWithRejected.filter((u) => u.status !== 'rejected');
  assert.equal(checkUniqueEmployeeId(activeOnly, 'REJECT-999'), true);
  assert.equal(checkUniqueEmployeeId(activeOnly, 'EMP-1001'), false);
});

test('verifyPassword validates matching PBKDF2 hash credentials and rejects incorrect ones or plaintext', async () => {
  const plainPassword = 'CorrectSecurePassword!987';
  const hashed = await hashPassword(plainPassword);
  assert.equal(await verifyPbkdf2Password(plainPassword, hashed), true);
  assert.equal(await verifyPbkdf2Password('WrongPassword', hashed), false);
  assert.equal(await verifyPbkdf2Password('', hashed), false);
  assert.equal(await verifyPbkdf2Password(plainPassword, 'plaintext_password_not_hash'), false);
  assert.equal(await verifyPbkdf2Password(plainPassword, ''), false);
});

test('canBroadcastBreak strictly gates unapproved and suspended members', () => {
  const approvedUser = { status: 'approved' as UserApprovalStatus, role: 'user' as UserRole };
  const pendingUser = { status: 'pending_approval' as UserApprovalStatus, role: 'user' as UserRole };
  const suspendedUser = { status: 'suspended' as UserApprovalStatus, role: 'user' as UserRole };

  assert.equal(canBroadcastBreak(approvedUser), true);
  assert.equal(canBroadcastBreak(pendingUser), false);
  assert.equal(canBroadcastBreak(suspendedUser), false);
});

test('canAccessAdminPortal permits verified admins and blocks standard users', () => {
  const admin = { role: 'community_admin' as UserRole, status: 'approved' as UserApprovalStatus };
  const regularUser = { role: 'user' as UserRole, status: 'approved' as UserApprovalStatus };
  const suspendedAdmin = { role: 'community_admin' as UserRole, status: 'suspended' as UserApprovalStatus };

  assert.equal(canAccessAdminPortal(admin), true);
  assert.equal(canAccessAdminPortal(regularUser), false);
  assert.equal(canAccessAdminPortal(suspendedAdmin), false);
});

test('Forgot password lifecycle: admin approval enables passwordless login, forces password change, and invalidates temporary state', async () => {
  const user = {
    email: 'karthik@example.com',
    password: await hashPassword('OldPassword@123'),
    passwordResetRequested: true,
    passwordResetApproved: false,
    mustChangePassword: false,
  };

  // 1. Before approval, user cannot login without password
  assert.equal(canLoginWithoutPassword(user), false);

  // 2. Admin approves reset request
  processAdminResetApproval(user);
  assert.equal(user.passwordResetApproved, true);
  assert.equal(user.mustChangePassword, true);
  assert.equal(canLoginWithoutPassword(user), true);

  // 3. User sets new password
  const failResult = processPasswordChange(user, '123'); // Too short
  assert.equal(failResult.success, false);

  const newHash = await hashPassword('NewStrongPassword@2026');
  const successResult = processPasswordChange(user, newHash);
  assert.equal(successResult.success, true);
  assert.equal(user.password, newHash);
  assert.equal(user.passwordResetApproved, false);
  assert.equal(user.mustChangePassword, false);

  // 4. User cannot do passwordless login anymore
  assert.equal(canLoginWithoutPassword(user), false);
  // 5. Must authenticate with new password
  assert.equal(await verifyPbkdf2Password('NewStrongPassword@2026', user.password), true);
  assert.equal(await verifyPbkdf2Password('OldPassword@123', user.password), false);
});
